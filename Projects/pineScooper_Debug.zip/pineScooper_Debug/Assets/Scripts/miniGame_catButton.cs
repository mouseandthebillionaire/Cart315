﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miniGame_catButton : MonoBehaviour
{

	public Sprite[] catImages;

    /*************
     * 0 = normal
     * 1 = cool
     * 2 = dead
     ************/
    
	// Use this for initialization
	void Start(){
		miniGame.cb = this;
	}

	void OnMouseUpAsButton()
	{
		miniGame.S.ResetGame();
		LoadCat(0)

	}

	public void LoadCat(int img){
		GetComponent<SpiteRenderer>().sprite = catImages[img];
	}
}
