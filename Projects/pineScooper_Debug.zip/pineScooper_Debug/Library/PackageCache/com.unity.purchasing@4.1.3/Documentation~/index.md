# About Unity IAP

Unity IAP makes it easy to implement in-app purchases in your application across the most popular app stores.
