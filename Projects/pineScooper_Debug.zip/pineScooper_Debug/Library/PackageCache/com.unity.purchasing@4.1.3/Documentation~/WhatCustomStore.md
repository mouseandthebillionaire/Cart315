# What is a Custom Store

A custom store is a store that the In-App Purchasing package doesn't support out of the out of the box. It allows developers to create their own stores and build on top of the existing infrastructure of the package.

